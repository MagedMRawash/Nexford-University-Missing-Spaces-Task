Missing Spaces Task

The missing_spaces.txt file contains paragraphs of English text with the spaces removed.
Your task is to restore the missing spaces to the text, producing a restored_spaces.txt file.
The resulting file should contain the same number of lines, with no characters missing and no new characters other than spaces.

The training_data.txt file is provided for training.

The test_spaces.py script may be used for quality evaluation, as such:
$ python test_spaces.py <reference file> <test file>
(Note this script requires Python 3, so please make sure you have that installed before starting).

The script should also be used to check your result file is valid before submitting:
$ python test_spaces.py missing_spaces.txt restored_spaces.txt
(It should report 0.0 for Precision, Recall and F1 - but it shouldn't fail/error).

Please zip up your restored_spaces.txt file, together with any code files you've written, and a README file describing the method you used, and submit them.

Please submit your work within 24 hrs. Good luck!